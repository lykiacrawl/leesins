# OfficialAddons
Official addons approved by the EloBuddy team, made by quality addon developers.

## iCreative
### [EvadeIC](https://www.elobuddy.net/topic/34797-/)
Smooth. Fast. Awesome.
Even though being currently in beta, it still made it's way to the top Evade addon in no time, prepare yourself for smooth dodging.
